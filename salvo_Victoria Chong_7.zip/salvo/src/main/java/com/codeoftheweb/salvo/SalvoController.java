package com.codeoftheweb.salvo;

import com.codeoftheweb.salvo.Class.Game;
import com.codeoftheweb.salvo.Class.GamePlayer;
import com.codeoftheweb.salvo.Class.Player;
import com.codeoftheweb.salvo.Repository.GamePlayerRepository;
import com.codeoftheweb.salvo.Repository.GameRepository;
import com.codeoftheweb.salvo.Repository.PlayerRepository;
import com.codeoftheweb.salvo.Repository.ShipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {
    @Autowired
    private GameRepository gameRepository;
    @Autowired
    private GamePlayerRepository gamePlayerRepository;
    @Autowired
    private ShipRepository shipRepository;
    @Autowired
    private PlayerRepository playerRepository;
    @Autowired
    PasswordEncoder passwordEncoder;

    private boolean isGuest(Authentication authentication) {
        return authentication == null || authentication instanceof AnonymousAuthenticationToken;
    }

    @RequestMapping("/games")
    public Map<String, Object> getControllerDTO(Authentication authentication) {
        Map<String, Object> dto = new LinkedHashMap<>();
        if (isGuest(authentication)){
            dto.put("player", "Guest");
        }
        else {
            dto.put("player", playerRepository
                    .findByUserName(authentication.getName())
                    .makePlayerDTO());
        }
        dto.put("games", gameRepository.findAll()
                .stream()
                .map(x -> x.makeGameDTO())
                .collect(Collectors.toList()));
        return dto;
    }

    @RequestMapping("/game_view/{nn}")
    public ResponseEntity<Map> findGamePlayer(@PathVariable Long nn, Authentication authentication) {
        GamePlayer gamePlayer = gamePlayerRepository.findById(nn).get();
        if (playerRepository.findByUserName(authentication.getName())
                .getGamePlayer()
                .stream()
                .anyMatch(x->x.getId().equals(nn))){
            return new ResponseEntity<>(gamePlayer.makeGameViewDTO(), HttpStatus.ACCEPTED);
        }
        else{
            return new ResponseEntity<>(makeMap("No se puede ver", 0), HttpStatus.UNAUTHORIZED);
        }
    }

    @RequestMapping(path = "/players", method = RequestMethod.POST)
    public ResponseEntity<Map<String, Object>> createUser(@RequestParam String email, @RequestParam String password) {
        if (email.isEmpty()) {
            return new ResponseEntity<>(makeMap("error", "No name"), HttpStatus.FORBIDDEN);
        }
        Player player = playerRepository.findByUserName(email);
        if (player != null) {
            return new ResponseEntity<>(makeMap("error", "Username already exists"), HttpStatus.CONFLICT);
        }
        Player newPlayer = playerRepository.save(new Player(email, passwordEncoder.encode(password)));
        return new ResponseEntity<>(makeMap("id", newPlayer.getId()), HttpStatus.CREATED);
    }

    private Map<String, Object> makeMap(String key, Object value) {
        Map<String, Object> map = new HashMap<>();
        map.put(key, value);
        return map;
    }

    @PostMapping(path = "/games")
    public ResponseEntity<Map>createGame(Authentication authentication){
        LocalDateTime Tiempo = LocalDateTime.now();
        Game newgame = gameRepository.save(new Game(Tiempo));
        GamePlayer newGamePlayer = gamePlayerRepository.save(new GamePlayer(this.playerRepository
                .findByUserName(authentication.getName()),newgame,LocalDateTime.now()));
        return new ResponseEntity<>(makeMap("gpid", newGamePlayer.getId()), HttpStatus.ACCEPTED);
    }

    @PostMapping("/game/{game}/players")
    public ResponseEntity<Map<String, Object>>joinGameButton(@PathVariable Long game, Authentication authentication){
        if (playerRepository.findByUserName(authentication.getName()) == null){
            System.out.println("holi");
            return new ResponseEntity<>(makeMap("No esta autorizado", 0),HttpStatus.UNAUTHORIZED);
        }
        if (gameRepository.findById(game).isPresent()){
            if (gameRepository.getById(game).getId() == null){
                return new ResponseEntity<>(makeMap("No esta autorizado", 0), HttpStatus.FORBIDDEN);
        }}
        if (gameRepository.getById(game).getGamePlayer().size() >= 2){
            return new ResponseEntity<>(makeMap("Supero los jugadores", 0), HttpStatus.FORBIDDEN);
        }
        GamePlayer newGamePlayer = gamePlayerRepository.save(new GamePlayer(this.playerRepository
                .findByUserName(authentication.getName()),gameRepository.getById(game), LocalDateTime.now()));
        return new ResponseEntity<>(makeMap("gpid", newGamePlayer.getId()), HttpStatus.CREATED);
    }

}













